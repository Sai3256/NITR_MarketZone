// frontend/src/pages/Auth.tsx
import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import authBg from '@/assets/auth-background.jpg';
import logo from '@/assets/logo.png';

export default function Auth() {
  const [isLoading, setIsLoading] = useState(false);
  // This new state will hold error messages from the backend
  const [error, setError] = useState<string | null>(null);

  const navigate = useNavigate();
  const { login } = useAuth(); // Get the NEW login function from our context

  //  Login Submit Handler 
  const handleLoginSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null); // Clear previous errors

    // This is how you get form data when not using state
    const form = e.currentTarget;
    const email = (form.elements.namedItem('email') as HTMLInputElement).value;
    const password = (form.elements.namedItem('password') as HTMLInputElement).value;

    try {
      const res = await fetch('http://localhost:5001/api/auth/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, password }),
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.message || 'Login failed');
      }

      
      // data.user and data.token come from our backend controller
      login(data.user, data.token);
      navigate('/');
    } catch (err) {
      if (err instanceof Error) {
        setError(err.message);
      } else {
        setError('An unknown error occurred');
      }
    } finally {
      setIsLoading(false);
    }
  };

  //  Signup Submit Handler 
  const handleSignupSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);

    const form = e.currentTarget;
    // Get all form fields by their 'id' (which is used as 'name' by default)
    const name = (form.elements.namedItem('name') as HTMLInputElement).value;
    const phone = (form.elements.namedItem('phone') as HTMLInputElement).value;
    const email = (form.elements.namedItem('signup-email') as HTMLInputElement).value;
    const collegeName = (form.elements.namedItem('college') as HTMLInputElement).value;
    const campusLocation = (form.elements.namedItem('location') as HTMLInputElement).value;
    const academicYear = (form.elements.namedItem('year') as HTMLInputElement).value;
    const password = (form.elements.namedItem('signup-password') as HTMLInputElement).value;

    try {
      const res = await fetch('http://localhost:5001/api/auth/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          name,
          email,
          password,
          phone,
          collegeName,
          campusLocation,
          academicYear,
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.message || 'Sign up failed');
      }

      
      // Log the user in immediately after signup
      login(data.user, data.token);
      navigate('/');
    } catch (err) {
      if (err instanceof Error) {
        setError(err.message);
      } else {
        setError('An unknown error occurred');
      }
    } finally {
      setIsLoading(false);
    }
  };

  
  return (
    <div className="min-h-screen relative flex items-center justify-center p-4 overflow-hidden">
      <div className="absolute inset-0 z-0">
        <img src={authBg} alt="" className="w-full h-full object-cover opacity-40" />
        <div className="absolute inset-0 bg-gradient-to-br from-primary/20 via-background/90 to-accent/20"></div>
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,hsl(var(--primary)/0.1),transparent_50%)] animate-pulse"></div>
      </div>
      
      <div className="w-full max-w-md relative z-10">
        <div className="flex items-center justify-center space-x-3 mb-8 animate-fade-in">
          <img src={logo} alt="CampusCart" className="w-12 h-12 drop-shadow-lg" />
          <span className="font-bold text-3xl text-foreground">CampusCart</span>
        </div>

        <Tabs defaultValue="login" className="w-full animate-scale-in">
          <TabsList className="grid w-full grid-cols-2 bg-card/50 backdrop-blur-sm">
            <TabsTrigger value="login">Login</TabsTrigger>
            <TabsTrigger value="signup">Sign Up</TabsTrigger>
          </TabsList>

          <TabsContent value="login">
            <Card className="backdrop-blur-sm bg-card/95 shadow-2xl border-primary/20">
              <CardHeader>
                <CardTitle>Welcome back</CardTitle>
                <CardDescription>Login to your CampusCart account</CardDescription>
              </CardHeader>
              <CardContent>
                {/*  onSubmit points to handleLoginSubmit  */}
                <form onSubmit={handleLoginSubmit} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input id="email" type="email" placeholder="you@college.edu" required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="password">Password</Label>
                    <Input id="password" type="password" required />
                  </div>
                  {/*  Show error message  */}
                  {error && <p className="text-sm text-destructive">{error}</p>}
                  <Button type="submit" className="w-full" disabled={isLoading}>
                    {isLoading ? "Loading..." : "Login"}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="signup">
            <Card className="backdrop-blur-sm bg-card/95 shadow-2xl border-primary/20">
              <CardHeader>
                <CardTitle>Create account</CardTitle>
                <CardDescription>Join your campus marketplace</CardDescription>
              </CardHeader>
              <CardContent>
                {/*  onSubmit points to handleSignupSubmit */}
                <form onSubmit={handleSignupSubmit} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Full Name</Label>
                    <Input id="name" placeholder="John Doe" required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="phone">Phone Number</Label>
                    <Input id="phone" type="tel" placeholder="+91 98765 43210" required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="signup-email">College Email</Label>
                    <Input id="signup-email" type="email" placeholder="you@nitrkl.ac.in" required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="college">College Name</Label>
                    <Input id="college" placeholder="NIT Rourkela" required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="location">Campus Location</Label>
                    <Input id="location" placeholder="Sector 1, Rourkela" required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="year">Academic Year</Label>
                    <Input id="year" placeholder="1st Year, 2nd Year, etc." required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="signup-password">Password</Label>
                    <Input id="signup-password" type="password" required />
                  </div>
                  {/*  Show error message */}
                  {error && <p className="text-sm text-destructive">{error}</p>}
                  <Button type="submit" className="w-full" disabled={isLoading}>
                    {isLoading ? "Loading..." : "Create Account"}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}