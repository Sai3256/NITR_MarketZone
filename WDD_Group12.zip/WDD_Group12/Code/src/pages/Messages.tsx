// frontend/src/pages/Messages.tsx
import { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { useAuth, getAuthHeaders } from '@/contexts/AuthContext';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Navbar } from '@/components/Navbar';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { ArrowLeft, Send } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';

//  Types 
interface Message {
  _id: string;
  sender: string;
  recipient: string;
  content: string;
  createdAt: string;
}

interface Conversation {
  otherUserId: string;
  otherUserName: string;
  lastMessage: string;
  lastMessageAt: string;
  isLastMessageFromMe: boolean;
}

//  Helper for Avatars 
const getInitials = (name: string | undefined) => {
  if (!name) return '??';
  const names = name.split(' ');
  if (names.length > 1) {
    return names[0][0] + names[names.length - 1][0];
  }
  return name.substring(0, 2);
};

//  API Function: Fetch Inbox (Conversations) 
const fetchConversations = async (): Promise<Conversation[]> => {
  const res = await fetch('http://localhost:5001/api/messages', {
    headers: getAuthHeaders(),
  });
  if (!res.ok) {
    throw new Error('Failed to fetch conversations');
  }
  return res.json();
};

// API Function: Fetch Chat History 
const fetchChatHistory = async (
  otherUserId: string
): Promise<Message[]> => {
  const res = await fetch(
    `http://localhost:5001/api/messages/${otherUserId}`,
    {
      headers: getAuthHeaders(),
    }
  );
  if (!res.ok) {
    throw new Error('Failed to fetch chat history');
  }
  return res.json();
};

// Inbox View Component 
const InboxView = () => {
  const { data: conversations, isLoading } = useQuery<Conversation[]>({
    queryKey: ['conversations'],
    queryFn: fetchConversations,
  });

  return (
    <div className="container mx-auto px-4 py-8 max-w-2xl">
      <h1 className="text-2xl font-bold mb-4">Messages</h1>
      <div className="border border-border rounded-lg">
        {isLoading ? (
          <div className="p-4 space-y-4">
            <Skeleton className="h-16 w-full" />
            <Skeleton className="h-16 w-full" />
            <Skeleton className="h-16 w-full" />
          </div>
        ) : conversations && conversations.length > 0 ? (
          conversations.map((convo) => (
            <Link
              key={convo.otherUserId}
              to={`/messages/${convo.otherUserId}`}
              className="flex items-center gap-4 p-4 hover:bg-muted border-b last:border-b-0"
            >
              <Avatar>
                <AvatarFallback>
                  {getInitials(convo.otherUserName)}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1 overflow-hidden">
                <h3 className="font-semibold">{convo.otherUserName}</h3>
                <p className="text-sm text-muted-foreground truncate">
                  {convo.isLastMessageFromMe && 'You: '}
                  {convo.lastMessage}
                </p>
              </div>
              <time className="text-xs text-muted-foreground self-start">
                {new Date(convo.lastMessageAt).toLocaleDateString()}
              </time>
            </Link>
          ))
        ) : (
          <p className="p-8 text-center text-muted-foreground">
            You have no messages yet.
          </p>
        )}
      </div>
    </div>
  );
};

//  Chat Room View Component 
const ChatRoomView = ({ userId: otherUserId }: { userId: string }) => {
  //  UPDATED: Get markChatAsRead from useAuth 
  const { user, socket, markChatAsRead } = useAuth();
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const [newMessage, setNewMessage] = useState('');
  const scrollRef = useRef<HTMLDivElement>(null);

  // 1. Fetch chat history
  const { data: messages = [], isLoading: isLoadingHistory } =
    useQuery<Message[]>({
      queryKey: ['messages', otherUserId],
      queryFn: () => fetchChatHistory(otherUserId),
      enabled: !!otherUserId,
    });

  
  // 2. Mark this chat as read when the component mounts
  useEffect(() => {
    if (otherUserId) {
      markChatAsRead(otherUserId);
    }
    // We only want this to run when the chat partner ID changes
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [otherUserId]);
  

  // 3. Listen for new messages
  useEffect(() => {
    if (!socket) return;
    const handleNewMessage = (newMessage: Message) => {
      if (
        (newMessage.sender === user?._id && newMessage.recipient === otherUserId) ||
        (newMessage.sender === otherUserId && newMessage.recipient === user?._id)
      ) {
        queryClient.setQueryData<Message[]>(
          ['messages', otherUserId],
          (oldData = []) => [...oldData, newMessage]
        );
      }
    };
    socket.on('newMessage', handleNewMessage);
    return () => {
      socket.off('newMessage', handleNewMessage);
    };
  }, [socket, otherUserId, user, queryClient]);

  // 4. Auto-scroll
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages]);

  // 5. Send message
  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!socket || !newMessage.trim() || !otherUserId) return;
    socket.emit('sendMessage', {
      recipientId: otherUserId,
      content: newMessage,
    });
    setNewMessage('');
  };

  return (
    <div className="flex-1 flex flex-col container mx-auto px-4 py-8 max-w-2xl">
      <Button
        variant="ghost"
        onClick={() => navigate('/messages')} // Go back to Inbox
        className="mb-4 self-start"
      >
        <ArrowLeft className="h-4 w-4 mr-2" />
        Back to Inbox
      </Button>

      <div className="flex-1 space-y-4 p-4 border border-border rounded-lg overflow-y-auto">
        {isLoadingHistory ? (
          <Skeleton className="h-20 w-1/2" />
        ) : messages.length === 0 ? (
          <p className="text-center text-muted-foreground">
            No messages yet. Say hello!
          </p>
        ) : (
          messages.map((msg) => (
            <div
              key={msg._id}
              className={`flex gap-3 ${
                msg.sender === user?._id ? 'justify-end' : 'justify-start'
              }`}
            >
              {msg.sender !== user?._id && (
                <Avatar className="h-8 w-8">
                  <AvatarFallback className="text-xs">SL</AvatarFallback>
                </Avatar>
              )}
              <div
                className={`max-w-xs p-3 rounded-lg ${
                  msg.sender === user?._id
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-muted'
                }`}
              >
                <p>{msg.content}</p>
              </div>
              {msg.sender === user?._id && (
                <Avatar className="h-8 w-8">
                  <AvatarFallback className="text-xs">
                    {getInitials(user?.name)}
                  </AvatarFallback>
                </Avatar>
              )}
            </div>
          ))
        )}
        <div ref={scrollRef} />
      </div>

      <form onSubmit={handleSendMessage} className="mt-4 flex gap-2">
        <Input
          value={newMessage}
          onChange={(e) => setNewMessage(e.target.value)}
          placeholder="Type your message..."
          required
        />
        <Button type="submit" size="icon">
          <Send className="h-4 w-4" />
        </Button>
      </form>
    </div>
  );
};

//  Main Component: The Router 
export default function Messages() {
  const { userId } = useParams<{ userId?: string }>();

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />
      {/* If userId exists, show chat. If not, show inbox. */}
      {userId ? <ChatRoomView userId={userId} /> : <InboxView />}
    </div>
  );
}