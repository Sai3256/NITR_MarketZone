// frontend/src/pages/Profile.tsx
import { useState } from 'react';
import { Navbar } from '@/components/Navbar';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Mail,
  MapPin,
  Calendar,
  Edit,
  Trash2,
  ArrowLeft,
  Upload,
  X,
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useToast } from '@/hooks/use-toast';
import { useAuth, getAuthHeaders } from '@/contexts/AuthContext';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Skeleton } from '@/components/ui/skeleton';

// Listing type
interface Listing {
  _id: string;
  title: string;
  price: number;
  imageUrls: string[];
  location: string;
  category: string;
  description: string;
  createdAt: string;
}

// API function to fetch user's listings
const fetchMyListings = async (): Promise<Listing[]> => {
  const res = await fetch('http://localhost:5001/api/materials/my', {
    headers: getAuthHeaders(),
  });
  if (!res.ok) {
    throw new Error('Failed to fetch listings');
  }
  return res.json();
};

export default function Profile() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const { user, login } = useAuth();
  const queryClient = useQueryClient();

  const [isEditProfileOpen, setIsEditProfileOpen] = useState(false);
  const [isEditListingOpen, setIsEditListingOpen] = useState(false);

  
  const [profileForm, setProfileForm] = useState({
    name: user?.name || '',
    email: user?.email || '',
    phone: user?.phone || '',
    collegeName: user?.collegeName || '',
    campusLocation: user?.campusLocation || '',
    academicYear: user?.academicYear || '',
  });
  
  // Listing form state
  const [editingListing, setEditingListing] = useState<Listing | null>(null);
  const [listingForm, setListingForm] = useState({
    title: '',
    price: 0,
    location: '',
    description: '',
  });
  const [existingImages, setExistingImages] = useState<string[]>([]);
  const [newImageFiles, setNewImageFiles] = useState<FileList | null>(null);

  // fetching listings
  const {
    data: listings,
    isLoading: isLoadingListings, // isLoading is correct for useQuery
  } = useQuery<Listing[]>({
    queryKey: ['myListings'],
    queryFn: fetchMyListings,
  });

  //  DELETING a listing
  const deleteListingMutation = useMutation({
    mutationFn: async (id: string) => {
      const res = await fetch(`http://localhost:5001/api/materials/${id}`, {
        method: 'DELETE',
        headers: getAuthHeaders(),
      });
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.message || 'Failed to delete listing');
      }
      return res.json();
    },
    onSuccess: () => {
      toast({ title: 'Listing deleted successfully!' });
      queryClient.invalidateQueries({ queryKey: ['myListings'] });
    },
    onError: (error: Error) => {
      toast({ title: 'Error', description: error.message, variant: 'destructive' });
    },
  });

  //  UPDATING profile
  const updateProfileMutation = useMutation({
    mutationFn: async (updatedProfile: typeof profileForm) => {
      const res = await fetch('http://localhost:5001/api/auth/me', {
        method: 'PUT',
        headers: getAuthHeaders(),
        body: JSON.stringify(updatedProfile),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.message || 'Failed to update profile');
      }
      return data;
    },
    onSuccess: (data) => {
      login(data.user, data.token);
      toast({ title: 'Profile updated successfully!' });
      setIsEditProfileOpen(false);
    },
    onError: (error: Error) => {
      toast({ title: 'Error', description: error.message, variant: 'destructive' });
    },
  });

  //  UPDATING a listing
  const updateListingMutation = useMutation({
    mutationFn: async ({ id, formData }: { id: string; formData: FormData }) => {
      const res = await fetch(`http://localhost:5001/api/materials/${id}`, {
        method: 'PUT',
        headers: {
          'Authorization': getAuthHeaders()['Authorization'],
        },
        body: formData,
      });
      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.message || 'Failed to update listing');
      }
      return res.json();
    },
    onSuccess: () => {
      toast({ title: 'Listing updated successfully!' });
      queryClient.invalidateQueries({ queryKey: ['myListings'] });
      setIsEditListingOpen(false);
    },
    onError: (error: Error) => {
      toast({ title: 'Error', description: error.message, variant: 'destructive' });
    },
  });

  // Handler functions 
  const handleEditProfile = () => {
    setProfileForm({
      name: user?.name || '',
      email: user?.email || '',
      phone: user?.phone || '',
      collegeName: user?.collegeName || '',
      campusLocation: user?.campusLocation || '',
      academicYear: user?.academicYear || '',
    });
    setIsEditProfileOpen(true);
  };

  const handleSaveProfile = () => {
    updateProfileMutation.mutate(profileForm);
  };

  const handleEditListing = (listing: Listing) => {
    setEditingListing(listing);
    setListingForm({
      title: listing.title,
      price: listing.price,
      location: listing.location,
      description: listing.description,
    });
    setExistingImages(listing.imageUrls);
    setNewImageFiles(null);
    setIsEditListingOpen(true);
  };

  const handleRemoveExistingImage = (imageUrl: string) => {
    setExistingImages(existingImages.filter((url) => url !== imageUrl));
  };

  const handleSaveListing = () => {
    if (!editingListing) return;

    const formData = new FormData();
    formData.append('title', listingForm.title);
    formData.append('price', listingForm.price.toString());
    formData.append('location', listingForm.location);
    formData.append('description', listingForm.description);
    formData.append('existingImages', JSON.stringify(existingImages));

    if (newImageFiles) {
      for (let i = 0; i < newImageFiles.length; i++) {
        formData.append('images', newImageFiles[i]);
      }
    }
    
    updateListingMutation.mutate({
      id: editingListing._id,
      formData: formData,
    });
  };

  const handleDeleteListing = (id: string) => {
    if (window.confirm('Are you sure you want to delete this listing?')) {
      deleteListingMutation.mutate(id);
      setIsEditListingOpen(false);
    }
  };

  const getInitials = (name: string | undefined) => {
    if (!name) return '??';
    const names = name.split(' ');
    if (names.length > 1) {
      return names[0][0] + names[names.length - 1][0];
    }
    return name.substring(0, 2);
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto space-y-6">
          <Button
            variant="ghost"
            onClick={() => navigate('/')}
            className="mb-4"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Home
          </Button>

          {/* Profile Card */}
          <Card>
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="flex items-center space-x-4">
                  <Avatar className="h-20 w-20">
                    <AvatarFallback className="text-2xl">
                      {getInitials(user?.name).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <CardTitle className="text-2xl">{user?.name}</CardTitle>
                    <div className="flex flex-col gap-2 mt-2 text-sm text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <Mail className="h-4 w-4" />
                        {user?.email}
                      </div>
                      <div className="flex items-center gap-1">
                        <MapPin className="h-4 w-4" />
                        {user?.collegeName}
                      </div>
                      <div className="flex items-center gap-1">
                        <Calendar className="h-4 w-4" />
                        {user?.academicYear}
                      </div>
                    </div>
                  </div>
                </div>
                <Button variant="outline" onClick={handleEditProfile}>
                  Edit Profile
                </Button>
              </div>
            </CardHeader>
          </Card>

          {/*  Listings Card */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>My Listings</CardTitle>
                <Button onClick={() => navigate('/add-listing')}>
                  Add New Listing
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {isLoadingListings ? (
                  <p>Loading your listings...</p>
                ) : listings && listings.length > 0 ? (
                  listings.map((listing) => (
                    <div
                      key={listing._id}
                      className="flex gap-4 p-4 border border-border rounded-lg"
                    >
                      <img
                        src={listing.imageUrls[0]}
                        alt={listing.title}
                        className="w-32 h-32 object-cover rounded-lg"
                      />
                      <div className="flex-1">
                        <div className="flex items-start justify-between mb-2">
                          <div>
                            <Badge variant="secondary" className="mb-2">
                              {listing.category}
                            </Badge>
                            <h3 className="font-semibold text-lg">
                              {listing.title}
                            </h3>
                            <p className="text-2xl font-bold text-primary mt-1">
                              ₹{listing.price.toLocaleString()}
                            </p>
                          </div>
                          <div className="flex gap-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleEditListing(listing)}
                            >
                              <Edit className="h-4 w-4 mr-1" />
                              Edit
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleDeleteListing(listing._id)}
                              disabled={deleteListingMutation.isPending} // <-- CORRECTED
                            >
                              <Trash2 className="h-4 w-4 mr-1" />
                              {deleteListingMutation.isPending ? 'Deleting...' : 'Delete'} {/* <-- CORRECTED */}
                            </Button>
                          </div>
                        </div>
                        <p className="text-sm text-muted-foreground mb-2">
                          {listing.description}
                        </p> {/* <-- CORRECTED (was </Sg>) */}
                        <div className="flex items-center text-sm text-muted-foreground">
                          <MapPin className="h-4 w-4 mr-1" />
                          {listing.location}
                        </div>
                      </div>
                    </div>
                  ))
                ) : (
                  <p>You haven't listed any items yet.</p>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Activity Card */}
          <Card>
            <CardHeader>
              <CardTitle>Activity</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">Activity feed coming soon.</p>
            </CardContent>
          </Card>
        </div>
      </div>

      {/*  Profile Dialog */}
      <Dialog open={isEditProfileOpen} onOpenChange={setIsEditProfileOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Edit Profile</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="name">Full Name</Label>
              <Input
                id="name"
                value={profileForm.name}
                onChange={(e) =>
                  setProfileForm({ ...profileForm, name: e.target.value })
                }
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                value={profileForm.email}
                onChange={(e) =>
                  setProfileForm({ ...profileForm, email: e.target.value })
                }
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="phone">Phone</Label>
              <Input
                id="phone"
                type="tel"
                value={profileForm.phone}
                onChange={(e) =>
                  setProfileForm({ ...profileForm, phone: e.target.value })
                }
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="college">College</Label>
              <Input
                id="college"
                value={profileForm.collegeName}
                onChange={(e) =>
                  setProfileForm({ ...profileForm, collegeName: e.target.value })
                }
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setIsEditProfileOpen(false)}
            >
              Cancel
            </Button>
            <Button
              onClick={handleSaveProfile}
              disabled={updateProfileMutation.isPending} // <-- CORRECTED
            >
              {updateProfileMutation.isPending ? 'Saving...' : 'Save Changes'} {/* <-- CORRECTED */}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/*  Listing Dialog */}
      <Dialog open={isEditListingOpen} onOpenChange={setIsEditListingOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Edit Listing</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4 max-h-[70vh] overflow-y-auto pr-4">
            <div className="space-y-2">
              <Label htmlFor="listingTitle">Title</Label>
              <Input
                id="listingTitle"
                value={listingForm.title}
                onChange={(e) =>
                  setListingForm({ ...listingForm, title: e.target.value })
                }
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="listingPrice">Price (₹)</Label>
              <Input
                id="listingPrice"
                type="number"
                value={listingForm.price}
                onChange={(e) =>
                  setListingForm({ ...listingForm, price: Number(e.target.value) })
                }
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="listingLocation">Location</Label>
              <Input
                id="listingLocation"
                value={listingForm.location}
                onChange={(e) =>
                  setListingForm({ ...listingForm, location: e.target.value })
                }
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="listingDescription">Description</Label>
              <Textarea
                id="listingDescription"
                value={listingForm.description}
                onChange={(e) =>
                  setListingForm({ ...listingForm, description: e.target.value })
                }
                rows={4}
              />
            </div>
            <div className="space-y-2">
              <Label>Current Images</Label>
              {existingImages.length > 0 ? (
                <div className="grid grid-cols-3 gap-2">
                  {existingImages.map((url) => (
                    <div key={url} className="relative group">
                      <img
                        src={url}
                        alt="Listing"
                        className="w-full h-24 object-cover rounded-md"
                      />
                      <Button
                        variant="destructive"
                        size="icon"
                        className="absolute top-0 right-0 h-6 w-6 opacity-0 group-hover:opacity-100 transition-opacity"
                        onClick={() => handleRemoveExistingImage(url)}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground">
                  No current images. Add new ones below.
                </p>
              )}
            </div>
            <div className="space-y-2">
              <Label>Add New Photos</Label>
              <label
                htmlFor="listing-images"
                className="block border-2 border-dashed border-border rounded-lg p-6 text-center hover:border-primary transition-colors cursor-pointer"
              >
                <Upload className="h-10 w-10 mx-auto text-muted-foreground mb-2" />
                <p className="text-sm text-muted-foreground">
                  {newImageFiles
                    ? `${newImageFiles.length} file(s) selected`
                    : 'Click to upload new images'}
                </p>
                <input
                  id="listing-images"
                  type="file"
                  className="hidden"
                  accept="image/*"
                  multiple
                  onChange={(e) => setNewImageFiles(e.target.files)}
                />
              </label>
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="destructive"
              onClick={() =>
                editingListing && handleDeleteListing(editingListing._id)
              }
              disabled={deleteListingMutation.isPending} // <-- CORRECTED
            >
              {deleteListingMutation.isPending ? 'Deleting...' : 'Delete Listing'} {/* <-- CORRECTED */}
            </Button>
            <div className="flex-1" />
            <Button
              variant="outline"
              onClick={() => setIsEditListingOpen(false)}
            >
              Cancel
            </Button>
            <Button
              onClick={handleSaveListing}
              disabled={updateListingMutation.isPending} // <-- CORRECTED
            >
              {updateListingMutation.isPending ? 'Saving...' : 'Save Changes'} {/* <-- CORRECTED */}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}