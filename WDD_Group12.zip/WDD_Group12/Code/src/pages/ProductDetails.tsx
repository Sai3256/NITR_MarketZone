// frontend/src/pages/ProductDetails.tsx
import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Navbar } from '@/components/Navbar';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { MapPin, User, Phone, Mail, ArrowLeft } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useQuery } from '@tanstack/react-query';
import { Skeleton } from '@/components/ui/skeleton';
import { useAuth, getAuthHeaders } from '@/contexts/AuthContext'; // --- Import useAuth ---

// Types (no change)
interface Seller {
  _id: string;
  name: string;
  phone: string;
  email: string;
}
interface ListingDetails {
  _id: string;
  title: string;
  price: number;
  imageUrls: string[];
  location: string;
  category: string;
  description: string;
  user: Seller;
}

//  API fetching function (no change) 
const fetchListing = async (id: string): Promise<ListingDetails> => {
  const res = await fetch(`http://localhost:5001/api/materials/${id}`);
  if (!res.ok) {
    throw new Error('Listing not found');
  }
  return res.json();
};

export default function ProductDetails() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { toast } = useToast();
  
  // UPDATED: Get 'socket' from useAuth 
  const { user: loggedInUser, socket } = useAuth();

  const [selectedImage, setSelectedImage] = useState(0);
  const [showOfferDialog, setShowOfferDialog] = useState(false);
  const [offerPrice, setOfferPrice] = useState('');

  //  useQuery (no change) 
  const {
    data: product,
    isLoading,
    isError,
  } = useQuery<ListingDetails>({
    queryKey: ['listing', id],
    queryFn: () => fetchListing(id!),
    enabled: !!id,
  });

  //  Loading/Error states (no change) 
  if (isLoading) {
    return <ProductDetailsSkeleton />;
  }

  if (isError || !product) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container mx-auto px-4 py-8 text-center">
          <h1 className="text-2xl font-bold text-destructive">Listing not found.</h1>
          <Button variant="ghost" className="gap-2 mt-4" onClick={() => navigate('/')}>
            <ArrowLeft className="h-4 w-4" />
            Back to Home
          </Button>
        </div>
      </div>
    );
  }

  const isOwner = loggedInUser?._id === product.user._id;
  const minOffer = product.price * 0.95;

  const handleChatWithSeller = () => {
    navigate(`/messages/${product.user._id}`);
  };

  const handleBuyNow = () => {
    setShowOfferDialog(true);
  };

  //  UPDATED: handleSubmitOffer now has real utility 
  const handleSubmitOffer = () => {
    const offer = parseFloat(offerPrice);
    
    // 1. Validate the offer
    if (!offer || offer < minOffer) {
      toast({
        title: 'Invalid Offer',
        description: `Offer must be at least ₹${minOffer.toLocaleString()} (95% of listing price)`,
        variant: 'destructive',
      });
      return;
    }

    // 2. Check if socket is connected
    if (!socket) {
      toast({
        title: 'Error',
        description: 'Chat connection not ready. Please try again.',
        variant: 'destructive',
      });
      return;
    }

    // 3. Format and send the message
    const messageContent = `I'd like to make an offer of ₹${offer.toLocaleString()} for your item: "${product.title}"`;
    
    socket.emit('sendMessage', {
      recipientId: product.user._id,
      content: messageContent,
    });

    // 4. Close dialog, show toast, and navigate
    toast({
      title: 'Offer Sent!',
      description: 'Your offer has been sent to the seller as a message.',
    });
    setShowOfferDialog(false);
    
    // Navigate to the chat room so the user can see their sent message
    setTimeout(() => navigate(`/messages/${product.user._id}`), 500);
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto">
          <Button variant="ghost" className="gap-2 mb-4" onClick={() => navigate('/')}>
            <ArrowLeft className="h-4 w-4" />
            Back to Home
          </Button>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Image Gallery */}
            <div className="space-y-4">
              <div className="aspect-square overflow-hidden rounded-lg bg-muted">
                <img
                  src={product.imageUrls[selectedImage]}
                  alt={product.title}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="grid grid-cols-4 gap-2">
                {product.imageUrls.map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => setSelectedImage(idx)}
                    className={`aspect-square overflow-hidden rounded-lg border-2 transition-all ${
                      selectedImage === idx ? 'border-primary' : 'border-transparent'
                    }`}
                  >
                    <img
                      src={img}
                      alt={`${product.title} ${idx + 1}`}
                      className="w-full h-full object-cover"
                    />
                  </button>
                ))}
              </div>
            </div>

            {/* Product Info */}
            <div className="space-y-6">
              <div>
                <Badge variant="secondary" className="mb-2">
                  {product.category}
                </Badge>
                <h1 className="text-3xl font-bold mb-4">{product.title}</h1>
                <p className="text-4xl font-bold text-primary mb-4">
                  ₹{product.price.toLocaleString()}
                </p>
                <div className="flex items-center text-muted-foreground mb-6">
                  <MapPin className="h-5 w-5 mr-2" />
                  {product.location}
                </div>
              </div>

              <div className="space-y-4">
                {isOwner ? (
                  <Button variant="outline" size="lg" className="w-full" disabled>
                    This is your listing
                  </Button>
                ) : (
                  <>
                    <Button onClick={handleBuyNow} size="lg" className="w-full">
                      Buy Now
                    </Button>
                    <Button
                      onClick={handleChatWithSeller}
                      variant="outline"
                      size="lg"
                      className="w-full"
                    >
                      Chat with Seller
                    </Button>
                  </>
                )}
              </div>

              <Card>
                <CardContent className="p-6">
                  <h3 className="font-semibold text-lg mb-4">Description</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    {product.description}
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <h3 className="font-semibold text-lg mb-4">Seller Information</h3>
                  <div className="space-y-3">
                    <div className="flex items-center gap-2">
                      <User className="h-4 w-4 text-muted-foreground" />
                      <span>{product.user.name}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Phone className="h-4 w-4 text-muted-foreground" />
                      <span>{product.user.phone}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Mail className="h-4 w-4 text-muted-foreground" />
                      <span>{product.user.email}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>

      {/* Dialog (no change to JSX)  */}
      <Dialog open={showOfferDialog} onOpenChange={setShowOfferDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Make an Offer</DialogTitle>
            <DialogDescription>
              Submit your price offer to the seller. Minimum offer: ₹
              {minOffer.toLocaleString()} (95% of listing price)
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="offer">Your Offer (₹)</Label>
              <Input
                id="offer"
                type="number"
                placeholder={`Min: ${minOffer.toLocaleString()}`}
                value={offerPrice}
                onChange={(e) => setOfferPrice(e.target.value)}
                min={minOffer}
              />
            </div>
            <p className="text-sm text-muted-foreground">
              Listed Price: ₹{product.price.toLocaleString()}
            </p>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowOfferDialog(false)}>
              Cancel
            </Button>
            <Button onClick={handleSubmitOffer}>
              Send Offer
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}


const ProductDetailsSkeleton = () => (
  <div className="min-h-screen bg-background">
    <Navbar />
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-6xl mx-auto">
        <Skeleton className="h-8 w-32 mb-4" />
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Image Gallery Skeleton */}
          <div className="space-y-4">
            <Skeleton className="aspect-square w-full rounded-lg" />
            <div className="grid grid-cols-4 gap-2">
              <Skeleton className="aspect-square w-full rounded-lg" />
              <Skeleton className="aspect-square w-full rounded-lg" />
              <Skeleton className="aspect-square w-full rounded-lg" />
              <Skeleton className="aspect-square w-full rounded-lg" />
            </div>
          </div>
          {/* Product Info Skeleton */}
          <div className="space-y-6">
            <Skeleton className="h-6 w-24 mb-2" />
            <Skeleton className="h-10 w-3/4 mb-4" />
            <Skeleton className="h-12 w-1/2 mb-4" />
            <Skeleton className="h-6 w-48 mb-6" />
            <div className="space-y-4">
              <Skeleton className="h-12 w-full" />
              <Skeleton className="h-12 w-full" />
            </div>
            <Skeleton className="h-40 w-full" />
            <Skeleton className="h-32 w-full" />
          </div>
        </div>
      </div>
    </div>
  </div>
);