import { useState, useMemo } from "react";
import { Navbar } from "@/components/Navbar";
import { Sidebar } from "@/components/Sidebar";
import { ProductCard } from "@/components/ProductCard";
import { SearchBar } from "@/components/SearchBar";
import { Button } from "@/components/ui/button";
import { Link, useSearchParams } from "react-router-dom";
import heroImage from "@/assets/hero-image.jpg";
import { useQuery } from "@tanstack/react-query"; //  Import useQuery 
import { Skeleton } from "@/components/ui/skeleton"; //  Import Skeleton for loading 

//  Define the Listing type based on our backend model 
// This must match what your GET /api/materials endpoint returns
interface Listing {
  _id: string;
  title: string;
  price: number;
  imageUrls: string[]; // Backend sends an array
  location: string;
  category: string;
  createdAt: string; // We can use this for "latest" sorting
}

//  API fetching function 
const fetchListings = async (): Promise<Listing[]> => {
  const res = await fetch('http://localhost:5001/api/materials');
  if (!res.ok) {
    throw new Error('Failed to fetch listings');
  }
  return res.json();
};

//  sampleListings array 

export default function Index() {
  const [searchParams] = useSearchParams();
  const [searchQuery, setSearchQuery] = useState("");
  const [sortBy, setSortBy] = useState("latest");
  const [minPrice, setMinPrice] = useState("");
  const [maxPrice, setMaxPrice] = useState("");

  const categoryFromUrl = searchParams.get("category");

  //  Use useQuery to fetch data 
  const {
    data: listings,
    isLoading,
    isError,
  } = useQuery<Listing[]>({
    queryKey: ['listings'],
    queryFn: fetchListings,
  });

  //  Your filter logic now uses 'listings' from useQuery 
  const filteredListings = useMemo(() => {
    // Start with the fetched data, or an empty array if not yet loaded
    let filtered = [...(listings || [])];

    // Filter by category
    if (categoryFromUrl) {
      filtered = filtered.filter(
        (listing) => listing.category.toLowerCase() === categoryFromUrl.toLowerCase()
      );
    }

    // Filter by search query
    if (searchQuery.trim()) {
      filtered = filtered.filter(
        (listing) =>
          listing.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          listing.location.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    // Filter by price range
    if (minPrice) {
      filtered = filtered.filter((listing) => listing.price >= Number(minPrice));
    }
    if (maxPrice) {
      filtered = filtered.filter((listing) => listing.price <= Number(maxPrice));
    }

    // Sort listings
    if (sortBy === "price-low") {
      filtered.sort((a, b) => a.price - b.price);
    } else if (sortBy === "price-high") {
      filtered.sort((a, b) => b.price - b.price);
    } else if (sortBy === 'latest') {
      // 'createdAt' is a string, so we need to compare dates
      filtered.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    }

    return filtered;
  }, [listings, categoryFromUrl, searchQuery, sortBy, minPrice, maxPrice]);

  //  Create a loading skeleton component 
  const LoadingSkeletons = () => (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
      {[...Array(8)].map((_, i) => (
        <div key={i} className="flex flex-col space-y-3">
          <Skeleton className="h-[125px] w-full rounded-xl aspect-video" />
          <div className="space-y-2">
            <Skeleton className="h-4 w-[200px]" />
            <Skeleton className="h-4 w-[100px]" />
          </div>
        </div>
      ))}
    </div>
  );

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="flex w-full">
        <Sidebar />
        <main className="flex-1">
          {/* Hero Section (No changes) */}
          <section className="relative h-[450px] overflow-hidden">
            <img
              src={heroImage}
              alt="College students marketplace"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-br from-accent/35 via-accent/25 to-accent/15 flex items-center">
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_30%,rgba(255,255,255,0.15),transparent_50%)]"></div>
              <div className="container mx-auto px-4 relative z-10">
                <div className="max-w-2xl">
                  <h1 className="text-4xl md:text-6xl font-bold mb-4 text-white drop-shadow-[0_4px_12px_rgba(0,0,0,0.8)] animate-fade-in">
                    Welcome to CampusCart
                  </h1>
                  <p className="text-lg md:text-xl text-white mb-8 drop-shadow-[0_2px_8px_rgba(0,0,0,0.7)] animate-fade-in">
                    Buy and sell textbooks, electronics, vehicles, and more within your college community
                  </p>
                  <Link to="/add-listing">
                    <Button size="lg" className="shadow-xl hover:shadow-2xl transition-shadow animate-scale-in">
                      Start Selling Now
                    </Button>
                  </Link>
                </div>
              </div>
            </div>
          </section>

          {/* Main Content */}
          <div className="container mx-auto px-4 py-8">
            <SearchBar
              searchQuery={searchQuery}
              setSearchQuery={setSearchQuery}
              sortBy={sortBy}
              setSortBy={setSortBy}
              minPrice={minPrice}
              setMinPrice={setMinPrice}
              maxPrice={maxPrice}
              setMaxPrice={setMaxPrice}
            />

            <div className="mb-8">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h2 className="text-3xl font-bold text-foreground">
                    {categoryFromUrl
                      ? `${categoryFromUrl.charAt(0).toUpperCase() + categoryFromUrl.slice(1)}`
                      : 'Recent Listings'}
                  </h2>
                  <p className="text-muted-foreground mt-1">{filteredListings.length} items available</p>
                </div>
              </div>
              
              {/*  Handle Loading, Error, and Empty states */}
              {isLoading ? (
                <LoadingSkeletons />
              ) : isError ? (
                <div className="text-center py-12">
                  <p className="text-destructive">Failed to load listings. Please try again.</p>
                </div>
              ) : filteredListings.length === 0 ? (
                <div className="text-center py-12">
                  <p className="text-muted-foreground">No listings found matching your criteria.</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                  {filteredListings.map((listing) => (
                    //  Pass the correct props to ProductCard 
                    <ProductCard
                      key={listing._id}
                      _id={listing._id}
                      title={listing.title}
                      price={listing.price}
                      imageUrl={listing.imageUrls[0]} // Pass the first image as the cover
                      location={listing.location}
                      category={listing.category}
                    />
                  ))}
                </div>
              )}
            </div>

          </div>
        </main>
      </div>
    </div>
  );
}