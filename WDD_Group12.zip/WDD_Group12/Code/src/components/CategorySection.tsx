import { Book, Laptop, Bike, Shirt, Package, Home } from "lucide-react";
import { Link } from "react-router-dom";

const categories = [
  { name: "Books", icon: Book, color: "bg-blue-100 text-blue-600", path: "/?category=books" },
  { name: "Electronics", icon: Laptop, color: "bg-purple-100 text-purple-600", path: "/?category=electronics" },
  { name: "Vehicles", icon: Bike, color: "bg-green-100 text-green-600", path: "/?category=vehicles" },
  { name: "Clothing", icon: Shirt, color: "bg-pink-100 text-pink-600", path: "/?category=clothing" },
  { name: "Other", icon: Package, color: "bg-orange-100 text-orange-600", path: "/?category=other" },
];

export const CategorySection = () => {
  return (
    <div className="mb-8">
      <h2 className="text-2xl font-bold mb-6">Browse by Category</h2>
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
        {categories.map((category) => {
          const Icon = category.icon;
          return (
            <Link
              key={category.name}
              to={category.path}
              className="flex flex-col items-center p-6 bg-card rounded-xl border border-border hover:shadow-md transition-all hover:scale-105"
            >
              <div className={`w-16 h-16 rounded-full ${category.color} flex items-center justify-center mb-3`}>
                <Icon className="h-8 w-8" />
              </div>
              <span className="font-medium text-sm text-center">{category.name}</span>
            </Link>
          );
        })}
      </div>
    </div>
  );
};
