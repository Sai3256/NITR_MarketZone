import { Link, useNavigate } from "react-router-dom";
import { Home, Book, Laptop, Bike, Shirt, Package, LogOut } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/contexts/AuthContext";

const categories = [
  { name: "All Items", icon: Home, path: "/" },
  { name: "Books", icon: Book, path: "/?category=books" },
  { name: "Electronics", icon: Laptop, path: "/?category=electronics" },
  { name: "Vehicles", icon: Bike, path: "/?category=vehicles" },
  { name: "Clothing", icon: Shirt, path: "/?category=clothing" },
  { name: "Other", icon: Package, path: "/?category=other" },
];

export const Sidebar = () => {
  const { logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate("/auth");
  };

  return (
    <aside className="hidden lg:flex lg:flex-col w-64 bg-card border-r border-border h-[calc(100vh-4rem)] sticky top-16">
      <div className="flex-1 overflow-y-auto p-6">
        <h2 className="text-lg font-semibold mb-4">Categories</h2>
        <nav className="space-y-2">
          {categories.map((category) => {
            const Icon = category.icon;
            return (
              <Link
                key={category.name}
                to={category.path}
                className="flex items-center space-x-3 px-4 py-3 rounded-lg hover:bg-muted transition-colors"
              >
                <Icon className="h-5 w-5 text-muted-foreground" />
                <span className="text-sm font-medium">{category.name}</span>
              </Link>
            );
          })}
        </nav>
      </div>
      
      <div className="p-6 border-t border-border">
        <Button 
          variant="ghost" 
          className="w-full justify-start gap-2" 
          onClick={handleLogout}
        >
          <LogOut className="h-4 w-4" />
          Logout
        </Button>
      </div>
    </aside>
  );
};
