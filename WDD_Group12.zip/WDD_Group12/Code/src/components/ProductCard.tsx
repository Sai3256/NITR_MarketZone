import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { MapPin } from "lucide-react";
import { Link } from "react-router-dom";

//  Props to match backend data
interface ProductCardProps {
  _id: string; 
  title: string;
  price: number;
  imageUrl: string; 
  location: string;
  category: string;
}

export const ProductCard = ({
  _id,
  title,
  price,
  imageUrl,
  location,
  category,
}: ProductCardProps) => {
  return (
    <Card className="overflow-hidden hover:shadow-lg transition-all hover:-translate-y-1 duration-300 group">
      <div className="aspect-video overflow-hidden bg-muted relative">
        <img
          src={imageUrl}
          alt={title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
        />
        <Badge variant="secondary" className="absolute top-2 left-2 shadow-sm">
          {category}
        </Badge>
      </div>
      <CardContent className="p-3">
        <h3 className="font-semibold text-base line-clamp-1 mb-1">{title}</h3>
        <p className="text-xl font-bold text-primary mb-1">₹{price.toLocaleString()}</p>
        <div className="flex items-center text-xs text-muted-foreground">
          <MapPin className="h-3 w-3 mr-1" />
          <span className="line-clamp-1">{location}</span>
        </div>
      </CardContent>

      <CardFooter className="px-3 pb-3 pt-0 flex gap-2">
        {/* Use _id in the link */}
        <Link to={`/product/${_id}`} className="flex-1">
          <Button variant="outline" size="sm" className="w-full">View</Button>
        </Link>
        <Link to={`/product/${_id}?action=buy`} className="flex-1">
          <Button size="sm" className="w-full">Buy</Button>
        </Link>
      </CardFooter>
    </Card> 
  ); 
}; 