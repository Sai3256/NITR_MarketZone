// frontend/src/components/Navbar.tsx
import { Link, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { PlusCircle, User, Menu, MessageCircle, LogOut } from 'lucide-react';
import { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext'; //  Import useAuth 
import logo from '@/assets/logo.png';

export const Navbar = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  //  Get unreadCount from our context 
  const { logout, unreadCount } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/auth');
  };

  return (
    <nav className="sticky top-0 z-50 bg-background/80 backdrop-blur-md border-b border-border shadow-sm">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <Link to="/" className="flex items-center space-x-2 group">
            <img
              src={logo}
              alt="CampusCart"
              className="w-8 h-8 group-hover:scale-110 transition-transform"
            />
            <span className="font-bold text-xl text-foreground">CampusCart</span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-4">
            <Link to="/add-listing">
              <Button variant="default" className="gap-2">
                <PlusCircle className="h-4 w-4" />
                Sell Item
              </Button>
            </Link>
            <Link to="/messages">
              <Button variant="outline" size="icon" className="relative">
                <MessageCircle className="h-4 w-4" />
                {/*  Show count only if > 0  */}
                {unreadCount > 0 && (
                  <Badge className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 text-xs">
                    {unreadCount}
                  </Badge>
                )}
              </Button>
            </Link>
            <Link to="/profile">
              <Button variant="outline" size="icon">
                <User className="h-4 w-4" />
              </Button>
            </Link>
          </div>

          {/* Mobile Menu Button (no change) */}
          <button
            className="md:hidden"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            <Menu className="h-6 w-6" />
          </button>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden py-4 space-y-2">
            <Link to="/add-listing" className="block">
              <Button variant="default" className="w-full gap-2">
                <PlusCircle className="h-4 w-4" />
                Sell Item
              </Button>
            </Link>
            <Link to="/messages" className="block">
              <Button variant="outline" className="w-full gap-2">
                <MessageCircle className="h-4 w-4" />
                Messages {unreadCount > 0 && `(${unreadCount})`}
              </Button>
            </Link>
            <Link to="/profile" className="block">
              <Button variant="outline" className="w-full gap-2">
                <User className="h-4 w-4" />
                Profile
              </Button>
            </Link>
          </div>
        )}
      </div>
    </nav>
  );
};