// frontend/src/contexts/AuthContext.tsx
import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { io, Socket } from 'socket.io-client';
import { useQuery, useQueryClient } from '@tanstack/react-query';

const SOCKET_URL = 'http://localhost:5001';


interface User {
  _id: string; name: string; email: string; phone: string;
  collegeName: string; campusLocation: string; academicYear: string;
}

interface AuthContextType {
  user: User | null;
  token: string | null;
  isLoading: boolean;
  socket: Socket | null;
  unreadCount: number;
  markChatAsRead: (otherUserId: string) => void;
  login: (userData: User, token: string) => void;
  logout: () => void;
}


export const getAuthHeaders = () => {
  const token = localStorage.getItem('token');
  return {
    'Content-Type': 'application/json',
    Authorization: token ? `Bearer ${token}` : '',
  };
};

//  API function to fetch the user 
const fetchUser = async (): Promise<User> => {
  const res = await fetch('http://localhost:5001/api/auth/me', {
    method: 'GET',
    headers: getAuthHeaders(),
  });
  if (!res.ok) throw new Error('Invalid session');
  return res.json();
};

//  API function to fetch unread count 
const fetchUnreadCount = async (): Promise<{ count: number }> => {
  const res = await fetch('http://localhost:5001/api/messages/unread-count', {
    headers: getAuthHeaders(),
  });
  if (!res.ok) throw new Error('Failed to fetch unread count');
  return res.json();
};

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [token, setToken] = useState<string | null>(() => localStorage.getItem('token'));
  const [socket, setSocket] = useState<Socket | null>(null);
  const queryClient = useQueryClient();

  //  1. Query for fetching the user 
  const {
    data: user,
    isLoading: isUserLoading,
    isError: isUserError,
  } = useQuery<User>({
    queryKey: ['user'],
    queryFn: fetchUser,
    enabled: !!token, 
    retry: false, 
  });

  // 2. Query for fetching unread count 
  const { data: unreadData, isLoading: isUnreadLoading } = useQuery({
    queryKey: ['unreadCount'],
    queryFn: fetchUnreadCount,
    enabled: !!token, 
  });

  //  3. Combine loading states 
  const isLoading = isUserLoading || isUnreadLoading;

  const unreadCount = unreadData?.count || 0;

  // 4. Handle Bad Token 
  useEffect(() => {
    if (isUserError) {
      
      setToken(null);
      localStorage.removeItem('token');
      queryClient.clear(); // Clear all cached data
    }
  }, [isUserError, queryClient]);

  //  5. Manage Socket.io connection 
  useEffect(() => {
    if (token && user) { // Only connect if token is valid AND user is loaded
      const newSocket = io(SOCKET_URL, { auth: { token } });
      newSocket.on('connect', () => console.log('[Socket] Frontend connected:', newSocket.id));
      newSocket.on('disconnect', () => console.log('[Socket] Frontend disconnected'));
      
      newSocket.on('notifyUnread', () => {
        queryClient.invalidateQueries({ queryKey: ['unreadCount'] });
      });

      setSocket(newSocket);
    } else {
    
      if (socket) socket.disconnect();
      setSocket(null);
    }
    
   
    return () => {
      if (socket) socket.disconnect();
    };

  }, [token, user]); // Re-run when token or user state changes

  //  6. Updated Login/Logout functions 
  const login = (userData: User, token: string) => {
    // Manually set data in the cache so the app updates instantly
    queryClient.setQueryData(['user'], userData);
    queryClient.setQueryData(['unreadCount'], { count: 0 }); 
    setToken(token);
    localStorage.setItem('token', token);
  };

  const logout = () => {
    setToken(null);
    localStorage.removeItem('token');
    if (socket) socket.disconnect();
    queryClient.clear(); 
  };

  //  7. Updated Mark as Read function 
  const markChatAsRead = async (otherUserId: string) => {
    try {
      await fetch(`http://localhost:5001/api/messages/read/${otherUserId}`, {
        method: 'PUT',
        headers: getAuthHeaders(),
      });
      queryClient.invalidateQueries({ queryKey: ['unreadCount'] });
    } catch (error) {
      console.error('Failed to mark as read', error);
    }
  };

  //  8. The final Loading check 
  
  
  if (token && isLoading) {
    return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
  }

  return (
    <AuthContext.Provider
      value={{
        user: user || null, 
        token,
        isLoading: false, 
        socket,
        login,
        logout,
        unreadCount,
        markChatAsRead,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within AuthProvider');
  return context;
};