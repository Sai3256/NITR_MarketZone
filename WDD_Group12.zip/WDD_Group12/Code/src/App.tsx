// frontend/src/App.tsx
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider, useAuth } from "./contexts/AuthContext";
import Index from "./pages/Index";
import Auth from "./pages/Auth";
import AddListing from "./pages/AddListing";
import Profile from "./pages/Profile";
import ProductDetails from "./pages/ProductDetails";
import Messages from "./pages/Messages";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

// --- UPDATED: ProtectedRoute ---
// This component now waits for loading to finish
// and checks for a 'user' object instead of 'isAuthenticated'
const ProtectedRoute = ({ children }: { children: React.ReactNode }) => {
  const { user, isLoading } = useAuth();

  if (isLoading) {
    // Wait for auth context to finish loading before deciding
    return (
      <div className="min-h-screen flex items-center justify-center">
        Loading...
      </div>
    );
  }

  // If not loading and NO user, redirect to login
  if (!user) {
    return <Navigate to="/auth" replace />;
  }

  // If not loading and there IS a user, show the page
  return <>{children}</>;
};

// --- NEW: RedirectIfAuth ---
// This component is for public pages like Login/Register
// If the user is already logged in, it redirects them to the homepage
const RedirectIfAuth = ({ children }: { children: React.ReactNode }) => {
  const { user, isLoading } = useAuth();

  if (isLoading) {
    // Still wait for loading
    return (
      <div className="min-h-screen flex items-center justify-center">
        Loading...
      </div>
    );
  }

  // If not loading and there IS a user, redirect to homepage
  if (user) {
    return <Navigate to="/" replace />;
  }

  // If not loading and NO user, show the login page
  return <>{children}</>;
};

// --- We must wrap Routes in a component to use the useAuth hook ---
function AppRoutes() {
  return (
    <Routes>
      <Route
        path="/auth"
        element={
          <RedirectIfAuth>
            <Auth />
          </RedirectIfAuth>
        }
      />
      <Route
        path="/"
        element={
          <ProtectedRoute>
            <Index />
          </ProtectedRoute>
        }
      />
      <Route
        path="/add-listing"
        element={
          <ProtectedRoute>
            <AddListing />
          </ProtectedRoute>
        }
      />
      <Route
        path="/profile"
        element={
          <ProtectedRoute>
            <Profile />
          </ProtectedRoute>
        }
      />
      <Route
        path="/product/:id"
        element={
          <ProtectedRoute>
            <ProductDetails />
          </ProtectedRoute>
        }
      />
      
      <Route 
        path="/messages" 
        element={<ProtectedRoute><Messages /></ProtectedRoute>} 
      />

      <Route path="/messages/:userId" element={<ProtectedRoute><Messages /></ProtectedRoute>} />
      {}
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <AuthProvider>
            <AppRoutes />
          </AuthProvider>
        </BrowserRouter>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;