
import express from 'express';
import dotenv from 'dotenv';
import cors from 'cors';
import connectDB from './config/db';
import { createServer } from 'http'; // --- NEW: Import http ---
import { Server } from 'socket.io'; // --- NEW: Import Server ---
import jwt from 'jsonwebtoken';
import { IUserDocument } from './models/userModel';
import Message from './models/messageModel';

// --- Import all your route files ---
import authRoutes from './routes/authRoutes';
import materialRoutes from './routes/materialRoutes';
import messageRoutes from './routes/messageRoutes'; // --- NEW: Import message routes ---

// Load env vars
dotenv.config();

// Connect to database
connectDB();

const app = express();

// Middlewares
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// --- API ROUTES ---
app.use('/api/auth', authRoutes);
app.use('/api/materials', materialRoutes);
app.use('/api/messages', messageRoutes); // --- NEW: Use message routes ---

// --- NEW: Create HTTP server ---
const httpServer = createServer(app);

// --- NEW: Create Socket.io Server ---
const io = new Server(httpServer, {
  cors: {
    origin: 'http://localhost:8080', // Your frontend URL
    methods: ['GET', 'POST'],
  },
});

// --- NEW: Socket.io Authentication Middleware ---
io.use((socket, next) => {
  const token = socket.handshake.auth.token;
  if (!token) {
    return next(new Error('Authentication error: No token'));
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET!) as {
      id: string;
    };
    // Attach user ID to the socket object
    (socket as any).userId = decoded.id;
    next();
  } catch (err) {
    next(new Error('Authentication error: Invalid token'));
  }
});

// --- NEW: Socket.io Connection Logic ---
io.on('connection', (socket) => {
  const userId = (socket as any).userId;
  console.log(`[Socket] User connected: ${userId}`);

  // Join a "room" named after the user's ID
  // This allows us to send messages directly to a user
  socket.join(userId);

  // --- Handle sending a new message ---
  socket.on('sendMessage', async ({ recipientId, content }) => {
    try {
      // 1. Save the message (it will be 'isRead: false' by default)
      const message = await Message.create({
        sender: userId,
        recipient: recipientId,
        content: content,
      });

      // 2. Emit the new message to both users
      io.to(recipientId).emit('newMessage', message);
      io.to(userId).emit('newMessage', message);

      // --- NEW: 3. Send an 'unread' notification to the recipient ---
      io.to(recipientId).emit('notifyUnread'); 

    } catch (error) {
      console.error('Socket sendMessage error:', error);
    }
  });

  socket.on('disconnect', () => {
    console.log(`[Socket] User disconnected: ${userId}`);
  });
});

// --- FINAL: Start the HTTP server (not the 'app') ---
const PORT = process.env.PORT || 5001;

httpServer.listen(PORT, () => {
  console.log(
    `Server (with Socket.io) running in ${
      process.env.NODE_ENV || 'development'
    } mode on port ${PORT}`
  );
});