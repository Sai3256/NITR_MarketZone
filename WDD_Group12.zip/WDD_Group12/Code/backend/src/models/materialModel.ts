// backend/src/models/materialModel.ts
import mongoose, { Document, Model, Types } from 'mongoose';

// Interface for Listing properties
interface IMaterial {
  title: string;
  category: string;
  price: number;
  description: string;
  location: string;
  imageUrls: string[];
  user: Types.ObjectId; // Link to the user who posted
  sellerName: string; // Denormalized for easy frontend display
  sellerCollege: string; // Denormalized
}

// Interface for Listing Document
export interface IMaterialDocument extends IMaterial, Document {
  _id: Types.ObjectId;
  createdAt: Date;
  updatedAt: Date;
}

// Interface for Listing Model
interface IMaterialModel extends Model<IMaterialDocument> {}

const materialSchema = new mongoose.Schema<IMaterialDocument, IMaterialModel>(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      required: true,
      ref: 'User',
    },
    sellerName: {
      type: String,
      required: true,
    },
    sellerCollege: {
      type: String,
      required: true,
    },
    title: {
      type: String,
      required: true,
    },
    category: {
      type: String,
      required: true,
    },
    price: {
      type: Number,
      required: true,
    },
    description: {
      type: String,
      required: true,
    },
    location: {
      type: String,
      required: true,
    },
    imageUrls: [
      {
        type: String,
        required: true,
      },
    ],
  },
  {
    timestamps: true,
  }
);

const Material = mongoose.model<IMaterialDocument, IMaterialModel>(
  'Material',
  materialSchema
);

export default Material;