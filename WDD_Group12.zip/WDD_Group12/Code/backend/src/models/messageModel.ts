
import mongoose, { Document, Model, Types } from 'mongoose';

// Interface for Message properties
interface IMessage {
  sender: Types.ObjectId;
  recipient: Types.ObjectId;
  content: string;
  isRead: boolean; // --- NEW: Add this field ---
}

// Interface for Message Document
export interface IMessageDocument extends IMessage, Document {
  createdAt: Date;
}

// Interface for Message Model
interface IMessageModel extends Model<IMessageDocument> {}

const messageSchema = new mongoose.Schema<IMessageDocument, IMessageModel>(
  {
    sender: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    recipient: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    content: {
      type: String,
      required: true,
    },
    // --- NEW: Add the schema definition ---
    isRead: {
      type: Boolean,
      required: true,
      default: false, // Default to unread
    },
  },
  {
    timestamps: true,
  }
);

const Message = mongoose.model<IMessageDocument, IMessageModel>(
  'Message',
  messageSchema
);

export default Message;