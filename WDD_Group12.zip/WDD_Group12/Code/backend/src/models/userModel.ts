// backend/src/models/userModel.ts
import mongoose, { Document, Model, Types } from 'mongoose';
import bcrypt from 'bcryptjs';

// Interface for User properties
interface IUser {
  name: string;
  email: string;
  password: string;
  phone: string;
  collegeName: string;
  campusLocation: string;
  academicYear: string;
}

// Interface for User methods
export interface IUserMethods {
  matchPassword(enteredPassword: string): Promise<boolean>;
}

// Combine properties, Mongoose Document, and methods into one interface
// We explicitly add _id here to satisfy the controller
export interface IUserDocument extends IUser, IUserMethods, Document {
  _id: Types.ObjectId; // <-- Be EXTREMELY explicit
}

// Interface for the model (for static methods)
interface IUserModel extends Model<IUserDocument, {}, IUserMethods> {}

// Schema definition
const userSchema = new mongoose.Schema<IUserDocument, IUserModel, IUserMethods>(
  {
    name: { type: String, required: true },
    email: {
      type: String,
      required: [true, 'Please provide an email'],
      unique: true,
      lowercase: true,
      validate: {
        validator: function (email: string) {
          return /^[a-zA-Z0-9._-]+@nitrkl\.ac\.in$/.test(email);
        },
        message: 'Email must be a valid @nitrkl.ac.in address',
      },
    },
    password: {
      type: String,
      required: [true, 'Please provide a password'],
      minlength: 6,
    },
    phone: { type: String, required: true },
    collegeName: { type: String, required: true },
    campusLocation: { type: String, required: true },
    academicYear: { type: String, required: true },
  },
  {
    timestamps: true,
  }
);

userSchema.pre('save', async function (next) {
  if (!this.isModified('password')) {
    return next();
  }
  const salt = await bcrypt.genSalt(10);
  this.password = await bcrypt.hash(this.password, salt);
  next();
});

// Method implementation
userSchema.methods.matchPassword = async function (enteredPassword: string) {
  return await bcrypt.compare(enteredPassword, this.password);
};

// Model creation
const User = mongoose.model<IUserDocument, IUserModel>('User', userSchema);

export default User;