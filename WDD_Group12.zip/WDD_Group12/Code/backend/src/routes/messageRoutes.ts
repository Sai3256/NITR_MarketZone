// backend/src/routes/messageRoutes.ts
import express from 'express';
import {
  getChatHistory,
  getConversations,
  getUnreadCount, // --- NEW ---
  markAsRead,     // --- NEW ---
} from '../controllers/messageController';
import { protect } from '../middleware/authMiddleware';

const router = express.Router();

// GET /api/messages (Get all conversations)
router.route('/').get(protect, getConversations);

// GET /api/messages/unread-count (Get unread count)
router.route('/unread-count').get(protect, getUnreadCount); // --- NEW ---

// GET /api/messages/:otherUserId (Get chat history)
router.route('/:otherUserId').get(protect, getChatHistory);

// PUT /api/messages/read/:otherUserId (Mark as read)
router.route('/read/:otherUserId').put(protect, markAsRead); // --- NEW ---

export default router;