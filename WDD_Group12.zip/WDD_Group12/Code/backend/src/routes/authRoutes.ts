// backend/src/routes/authRoutes.ts
import express from 'express';
import { registerUser, loginUser, getUserProfile,updateUserProfile} from '../controllers/authController';
import { protect } from '../middleware/authMiddleware'; // This was missing

const router = express.Router();

// @route   POST /api/auth/register
router.post('/register', registerUser);

// @route   POST /api/auth/login
router.post('/login', loginUser);

// @route   GET /api/auth/me (Get profile)
// @route   PUT /api/auth/me (Update profile)
router
  .route('/me')
  .get(protect, getUserProfile)
  .put(protect, updateUserProfile); 

export default router;