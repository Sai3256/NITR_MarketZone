// backend/src/routes/materialRoutes.ts
import express from 'express';

import {
    createListing,
    getListings,
    getListingById,
    deleteListing,
    getMyListings,
    updateListing,
  } from '../controllers/materialController';

import { protect } from '../middleware/authMiddleware';
import upload from '../middleware/multer';

const router = express.Router();

// /api/materials
router
  .route('/')
  .get(getListings)
  .post(protect, upload.array('images', 10), createListing); // 'images' must match FormData key

router.route('/my').get(protect, getMyListings);

// /api/materials/:id
router
  .route('/:id')
  .get(getListingById)
  .delete(protect, deleteListing)
  .put(protect, upload.array('images', 10), updateListing);

export default router;