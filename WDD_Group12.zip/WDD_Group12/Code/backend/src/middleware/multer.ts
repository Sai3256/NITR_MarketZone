// backend/src/middleware/multer.ts
import multer from 'multer';
import { storage } from '../config/cloudinary';

// This function will check the file type
const fileFilter = (
  req: Express.Request,
  file: Express.Multer.File,
  cb: multer.FileFilterCallback
) => {
  // Check if the file is an image
  if (file.mimetype.startsWith('image/')) {
    cb(null, true); // Accept file
  } else {
    // Reject file
    cb(new Error('Only image files are allowed!') as any, false);
  }
};

const upload = multer({
  storage: storage,
  fileFilter: fileFilter,
  limits: { fileSize: 1024 * 1024 * 5 }, // 5MB file limit
});

export default upload;