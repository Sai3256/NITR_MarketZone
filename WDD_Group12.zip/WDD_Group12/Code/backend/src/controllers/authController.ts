// backend/src/controllers/authController.ts
import { Request, Response } from 'express';
import User, { IUserDocument } from '../models/userModel'; // Import the interface
import jwt from 'jsonwebtoken';
import { AuthRequest } from '../middleware/authMiddleware';

// Helper function
const generateToken = (id: string) => {
  const secret = process.env.JWT_SECRET;
  if (!secret) {
    console.error('JWT_SECRET is not defined');
    process.exit(1);
  }
  return jwt.sign({ id }, secret, {
    expiresIn: '30d',
  });
};

/**
 * @desc    Register a new user
 * @route   POST /api/auth/register
 * @access  Public
 */
export const registerUser = async (req: Request, res: Response) => {
  const {
    name,
    email,
    password,
    phone,
    collegeName,
    campusLocation,
    academicYear,
  } = req.body;

  try {
    const userExists = await User.findOne({ email });
    if (userExists) {
      return res.status(400).json({ message: 'User already exists' });
    }

    // --- THIS IS THE FIX ---
    const user: IUserDocument = await User.create({
      name,
      email,
      password,
      phone,
      collegeName,
      campusLocation,
      academicYear,
    });

    res.status(201).json({
      user: {
        _id: user._id, // This will now work
        name: user.name,
        email: user.email,
        phone: user.phone,
        collegeName: user.collegeName,
        campusLocation: user.campusLocation,
        academicYear: user.academicYear,
      },
      token: generateToken(user._id.toString()), // This will now work
    });
  } catch (error) {
    if (error instanceof Error) {
      res.status(400).json({ message: error.message });
    } else {
      res.status(500).json({ message: 'Server Error' });
    }
  }
};

/**
 * @desc    Auth user & get token (Login)
 * @route   POST /api/auth/login
 * @access  Public
 */
export const loginUser = async (req: Request, res: Response) => {
  const { email, password } = req.body;

  try {
    // --- THIS IS THE OTHER FIX ---
    const user: IUserDocument | null = await User.findOne({ email });

    if (user && (await user.matchPassword(password))) {
      res.json({
        user: {
          _id: user._id, // This will now work
          name: user.name,
          email: user.email,
          phone: user.phone,
          collegeName: user.collegeName,
          campusLocation: user.campusLocation,
          academicYear: user.academicYear,
        },
        token: generateToken(user._id.toString()), // This will now work
      });
    } else {
      res.status(401).json({ message: 'Invalid email or password' });
    }
  } catch (error) {
    if (error instanceof Error) {
      res.status(500).json({ message: error.message });
    } else {
      res.status(500).json({ message: 'Server Error' });
    }
  }
};

/**
 * @desc    Get user profile
 * @route   GET /api/auth/me
 * @access  Private
 */
export const getUserProfile = async (req: AuthRequest, res: Response) => {
  if (req.user) {
    res.json(req.user);
  } else {
    res.status(404).json({ message: 'User not found' });
  }
};

/**
 * @desc    Update user profile
 * @route   PUT /api/auth/profile
 * @access  Private
 */
export const updateUserProfile = async (req: AuthRequest, res: Response) => {
    const user = req.user as IUserDocument;
    const { name, email, phone, collegeName, campusLocation, academicYear } =
      req.body;
  
    if (user) {
      user.name = name || user.name;
      user.email = email || user.email;
      user.phone = phone || user.phone;
      user.collegeName = collegeName || user.collegeName;
      user.campusLocation = campusLocation || user.campusLocation;
      user.academicYear = academicYear || user.academicYear;
  
      try {
        const updatedUser = await user.save();
        res.json({
          user: {
            _id: updatedUser._id,
            name: updatedUser.name,
            email: updatedUser.email,
            phone: updatedUser.phone,
            collegeName: updatedUser.collegeName,
            campusLocation: updatedUser.campusLocation,
            academicYear: updatedUser.academicYear,
          },
          token: req.headers.authorization?.split(' ')[1], // Send back the same token
        });
      } catch (error) {
        if (error instanceof Error && error.message.includes('E11000')) {
          res.status(400).json({ message: 'Email already exists' });
        } else {
          res.status(400).json({ message: 'User update failed' });
        }
      }
    } else {
      res.status(404).json({ message: 'User not found' });
    }
  };