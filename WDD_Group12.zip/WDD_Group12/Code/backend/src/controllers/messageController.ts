// backend/src/controllers/messageController.ts
import { Response } from 'express';
import { AuthRequest } from '../middleware/authMiddleware';
import Message from '../models/messageModel';
import { IUserDocument } from '../models/userModel';
import mongoose from 'mongoose';

/**
 * @desc    Get chat history with another user
 * @route   GET /api/messages/:otherUserId
 * @access  Private
 */
export const getChatHistory = async (req: AuthRequest, res: Response) => {
  const user = req.user as IUserDocument;
  const otherUserId = req.params.otherUserId;

  try {
    // Find all messages sent OR received between the two users
    const messages = await Message.find({
      $or: [
        { sender: user._id, recipient: otherUserId },
        { sender: otherUserId, recipient: user._id },
      ],
    }).sort({ createdAt: 'asc' }); // Sort by oldest first

    res.json(messages);
  } catch (error) {
    if (error instanceof Error) {
      res.status(500).json({ message: error.message });
    }
  }
};

/**
 * @desc    Get all conversations for the logged-in user
 * @route   GET /api/messages
 * @access  Private
 */
export const getConversations = async (req: AuthRequest, res: Response) => {
    const user = req.user as IUserDocument;
  
    try {
      const conversations = await Message.aggregate([
        // 1. Find all messages where user is sender or recipient
        {
          $match: {
            $or: [
              { sender: user._id },
              { recipient: user._id }
            ],
          },
        },
        // 2. Sort them by date
        {
          $sort: { createdAt: -1 },
        },
        // 3. Group by the two participants
        {
          $group: {
            _id: {
              $cond: {
                if: { $eq: ['$sender', user._id] },
                then: '$recipient',
                else: '$sender',
              },
            },
            lastMessage: { $first: '$content' },
            lastMessageAt: { $first: '$createdAt' },
            lastSender: { $first: '$sender' },
          },
        },
        // 4. Look up the "other user's" details
        {
          $lookup: {
            from: 'users', // The 'users' collection
            localField: '_id',
            foreignField: '_id',
            as: 'otherUser',
          },
        },
        // 5. De-construct the 'otherUser' array
        {
          $unwind: '$otherUser',
        },
        // 6. Project the final shape
        {
          $project: {
            _id: 0,
            otherUserId: '$_id',
            otherUserName: '$otherUser.name',
            lastMessage: '$lastMessage',
            lastMessageAt: '$lastMessageAt',
            isLastMessageFromMe: { $eq: ['$lastSender', user._id] }
          },
        },
        // 7. Sort by the last message date
        {
          $sort: { lastMessageAt: -1 }
        }
      ]);
  
      res.json(conversations);
    } catch (error) {
      if (error instanceof Error) {
        res.status(500).json({ message: error.message });
      }
    }
  };

  // ... (keep getChatHistory and getConversations)

/**
 * @desc    Get user's unread message count
 * @route   GET /api/messages/unread-count
 * @access  Private
 */
export const getUnreadCount = async (req: AuthRequest, res: Response) => {
    const user = req.user as IUserDocument;
    try {
      const count = await Message.countDocuments({
        recipient: user._id,
        isRead: false,
      });
      res.json({ count });
    } catch (error) {
      if (error instanceof Error) {
        res.status(500).json({ message: error.message });
      }
    }
  };
  
  /**
   * @desc    Mark messages from a user as read
   * @route   PUT /api/messages/read/:otherUserId
   * @access  Private
   */
  export const markAsRead = async (req: AuthRequest, res: Response) => {
    const user = req.user as IUserDocument;
    const otherUserId = req.params.otherUserId;
  
    try {
      // Update all messages *from* otherUser *to* me
      await Message.updateMany(
        { sender: otherUserId, recipient: user._id, isRead: false },
        { $set: { isRead: true } }
      );
      res.json({ message: 'Messages marked as read' });
    } catch (error) {
      if (error instanceof Error) {
        res.status(500).json({ message: error.message });
      }
    }
  };