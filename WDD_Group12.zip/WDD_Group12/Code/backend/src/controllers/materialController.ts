// backend/src/controllers/materialController.ts
import { Response } from 'express';
import { AuthRequest } from '../middleware/authMiddleware';
import Material from '../models/materialModel';
import { cloudinary } from '../config/cloudinary';
import { IUserDocument } from '../models/userModel';

/**
 * @desc    Create a new listing
 * @route   POST /api/materials
 * @access  Private
 */
export const createListing = async (req: AuthRequest, res: Response) => {
  const { title, category, price, description, location } = req.body;
  const files = req.files as Express.Multer.File[];
  const user = req.user as IUserDocument;

  if (!files || files.length === 0) {
    return res.status(400).json({ message: 'No images uploaded' });
  }

  try {
    // Get the URLs from Cloudinary
    const imageUrls = files.map((file) => file.path);

    const listing = new Material({
      title,
      category,
      price: Number(price),
      description,
      location,
      imageUrls,
      user: user._id,
      sellerName: user.name,
      sellerCollege: user.collegeName,
    });

    const createdListing = await listing.save();
    res.status(201).json(createdListing);
  } catch (error) {
    if (error instanceof Error) {
      res.status(400).json({ message: error.message });
    } else {
      res.status(500).json({ message: 'Server Error' });
    }
  }
};

/**
 * @desc    Get all listings
 * @route   GET /api/materials
 * @access  Public
 */
export const getListings = async (req: AuthRequest, res: Response) => {
  try {
    // Find all materials, sort by newest first
    const listings = await Material.find({}).sort({ createdAt: -1 });
    res.json(listings);
  } catch (error) {
    if (error instanceof Error) {
      res.status(500).json({ message: error.message });
    }
  }
};

/**
 * @desc    Get single listing by ID
 * @route   GET /api/materials/:id
 * @access  Public
 */
export const getListingById = async (req: AuthRequest, res: Response) => {
  try {
    const listing = await Material.findById(req.params.id).populate(
        'user',
        'name email phone'
      );
    if (listing) {
      res.json(listing);
    } else {
      res.status(404).json({ message: 'Listing not found' });
    }
  } catch (error) {
    if (error instanceof Error) {
      res.status(500).json({ message: error.message });
    }
  }
};

/**
 * @desc    Delete a listing
 * @route   DELETE /api/materials/:id
 * @access  Private
 */
export const deleteListing = async (req: AuthRequest, res: Response) => {
  const user = req.user as IUserDocument;

  try {
    const listing = await Material.findById(req.params.id);

    if (!listing) {
      return res.status(404).json({ message: 'Listing not found' });
    }

    // Check if the logged-in user is the owner of the listing
    if (listing.user.toString() !== user._id.toString()) {
      return res.status(401).json({ message: 'User not authorized' });
    }

    // --- Delete images from Cloudinary ---
    for (const imageUrl of listing.imageUrls) {
      // Extract public_id from URL (e.g., .../upload/v12345/folder/image.jpg)
      const publicId = imageUrl.split('/').pop()?.split('.')[0];
      if (publicId) {
        await cloudinary.uploader.destroy(`campuscart_listings/${publicId}`);
      }
    }

    // --- Delete listing from MongoDB ---
    await listing.deleteOne();

    res.json({ message: 'Listing removed' });
  } catch (error) {
    if (error instanceof Error) {
      res.status(500).json({ message: error.message });
    }
  }
};

/**
 * @desc    Get listings for the logged-in user
 * @route   GET /api/materials/my
 * @access  Private
 */
export const getMyListings = async (req: AuthRequest, res: Response) => {
    const user = req.user as IUserDocument;
  
    try {
      const listings = await Material.find({ user: user._id }).sort({
        createdAt: -1,
      });
      res.json(listings);
    } catch (error) {
      if (error instanceof Error) {
        res.status(500).json({ message: error.message });
      }
    }
  };


/**
 * @desc    Update a listing
 * @route   PUT /api/materials/:id
 * @access  Private
 */
export const updateListing = async (req: AuthRequest, res: Response) => {
  const { title, price, description, location, category, existingImages } =
    req.body;
  const user = req.user as IUserDocument;

  try {
    const listing = await Material.findById(req.params.id);

    if (!listing) {
      return res.status(404).json({ message: 'Listing not found' });
    }

    // Check if the logged-in user is the owner
    if (listing.user.toString() !== user._id.toString()) {
      return res.status(401).json({ message: 'User not authorized' });
    }

    // 1. Get URLs of newly uploaded images
    const newImageUrls = (req.files as Express.Multer.File[]).map(
      (file) => file.path
    );

    // 2. Get the list of existing images to keep (sent from frontend)
    const imagesToKeep: string[] = existingImages
      ? JSON.parse(existingImages)
      : [];

    // 3. Find which old images to delete
    const imagesToDelete = listing.imageUrls.filter(
      (url) => !imagesToKeep.includes(url)
    );

    // 4. Delete removed images from Cloudinary
    for (const imageUrl of imagesToDelete) {
      // Extract public_id from URL
      const publicIdWithFolder = imageUrl.substring(
        imageUrl.indexOf('campuscart_listings/')
      );
      const publicId = publicIdWithFolder.substring(
        0,
        publicIdWithFolder.lastIndexOf('.')
      );
      if (publicId) {
        await cloudinary.uploader.destroy(publicId);
      }
    }

    // 5. Update the listing's fields
    listing.title = title || listing.title;
    listing.price = price || listing.price;
    listing.description = description || listing.description;
    listing.location = location || listing.location;
    listing.category = category || listing.category;
    listing.imageUrls = [...imagesToKeep, ...newImageUrls]; // Combine old and new

    const updatedListing = await listing.save();
    res.json(updatedListing);
  } catch (error) {
    if (error instanceof Error) {
      res.status(500).json({ message: error.message });
    }
  }
};
